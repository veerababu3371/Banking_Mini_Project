package com.capgemini.bean;

import java.sql.Date;

public class Transaction {
	Long accountId;
	String type;
	Date transactiondate;
	Double amount;
	Integer transactionId;

	/**
	 * 
	 */
	public Transaction() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param accountId
	 * @param type
	 * @param transactiondate
	 * @param amount
	 * @param transactionId
	 */
	public Transaction(Long accountId, String type, Date transactiondate, Double amount, Integer transactionId) {
		super();
		this.accountId = accountId;
		this.type = type;
		this.transactiondate = transactiondate;
		this.amount = amount;
		this.transactionId = transactionId;
	}

	/**
	 * @return the accountId
	 */
	public Long getAccountId() {
		return accountId;
	}

	/**
	 * @param accountId the accountId to set
	 */
	public void setAccountId(Long accountId) {
		this.accountId = accountId;
	}

	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}

	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}

	/**
	 * @return the transactiondate
	 */
	public Date getTransactiondate() {
		return transactiondate;
	}

	/**
	 * @param transactiondate the transactiondate to set
	 */
	public void setTransactiondate(Date transactiondate) {
		this.transactiondate = transactiondate;
	}

	/**
	 * @return the amount
	 */
	public Double getAmount() {
		return amount;
	}

	/**
	 * @param amount the amount to set
	 */
	public void setAmount(Double amount) {
		this.amount = amount;
	}

	/**
	 * @return the transactionId
	 */
	public Integer getTransactionId() {
		return transactionId;
	}

	/**
	 * @param transactionId the transactionId to set
	 */
	public void setTransactionId(Integer transactionId) {
		this.transactionId = transactionId;
	}

	@Override
	public String toString() {
		return "Transaction [accountId=" + accountId + ", type=" + type + ", transactiondate=" + transactiondate
				+ ", amount=" + amount + ", transactionId=" + transactionId + "]";
	}

}