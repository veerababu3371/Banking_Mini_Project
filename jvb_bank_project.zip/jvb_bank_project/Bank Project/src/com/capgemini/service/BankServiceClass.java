package com.capgemini.service;

import java.sql.SQLException;
import java.util.List;

import com.capgemini.bean.Account;
import com.capgemini.bean.Transaction;
import com.capgemini.dao.BankDaoClass;
import com.capgemini.dao.BankDaoInterface;

public class BankServiceClass implements BankServiceInterface {
	BankDaoClass bdc = new BankDaoClass();

	@Override
	public String addAccount(Account a) throws ClassNotFoundException, SQLException {
		if (a.getFirstName().length() >= 3 && a.getLastName().length() >= 3 && a.getFathersName().length() >= 3
				&& a.getMothersName().length() >= 3 && a.getAddress().length() >= 6) {

			Long max = 999999L;
			Long min = 100000L;
			Long rand;
			boolean flag = true;
			do {
				rand = (long) (Math.random() * (max - min + 1) + min);
				flag = checkUniqueId(rand);
			} while (flag == true);
			a.setAccountId(rand);

			Account list = new Account();
			String str = bdc.addAccount(a);
			list = listing(rand);
			if (str.equalsIgnoreCase("created")) {
				str = list.toString();
			}
			return str;
		}
		return "invalid";
	}

	public boolean checkUniqueId(Long rand) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub

		boolean flag = bdc.uniqueIds(rand);
		return flag;
	}

	@Override
	public String deposit(Long accountId, Double amount) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		if (amount > 0) {

			bdc.deposit(accountId, amount);
		}

		return "success";
	}

	@Override
	public String withDraw(Long accountId, Double amount) throws SQLException, ClassNotFoundException {
		double cbalance = showBalance(accountId);
		if (amount > 0 && amount <= cbalance) {

			return bdc.withDraw(accountId, amount);
		}
		return "Invalid Amount";
	}

	@Override
	public Double showBalance(Long accountId) throws SQLException, ClassNotFoundException {

		return bdc.showBalance(accountId);
	}

	@Override
	public String fundTransfer(Long accountId1, Long accountId2, Double amount)
			throws ClassNotFoundException, SQLException {

		if (amount > 0) {
			return bdc.fundTransfer(accountId1, accountId2, amount);
		}
		return "Invalid amount";
	}

	@Override
	public void printTransaction(Long accountId) throws SQLException {
		// TODO Auto-generated method stub
//		bdc=new BankDaoClass();
		bdc.printTransaction(accountId);
	}

	public boolean validate(String password, String rePassword) {
		if (password.equals(rePassword)) {
			return true;
		}
		return false;

	}

	public boolean checkAccount(Long id, String password) throws ClassNotFoundException, SQLException {
		return bdc.checkAccount(id, password);
	}

	public Account listing(Long id) throws SQLException {

		return bdc.listing(id);
	}
}
