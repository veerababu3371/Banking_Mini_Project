package com.capgemini.service;

import java.sql.SQLException;
//import java.util.List;

import com.capgemini.bean.Account;
//import com.capgemini.bean.Transaction;

public interface BankServiceInterface {
	
	public String addAccount(Account a) throws ClassNotFoundException, SQLException;

	public String deposit(Long accountId, Double amount) throws ClassNotFoundException, SQLException;

	public String withDraw(Long accountId, Double amount) throws SQLException, ClassNotFoundException;

	public Double showBalance(Long accountId) throws SQLException, ClassNotFoundException;

	public String fundTransfer(Long accountId1, Long accountId2, Double amount)
			throws ClassNotFoundException, SQLException;

	public void printTransaction(Long accountId) throws SQLException;

	public boolean validate(String password, String rePassword);

	public boolean checkUniqueId(Long rand) throws ClassNotFoundException, SQLException;

	public boolean checkAccount(Long id, String password) throws ClassNotFoundException, SQLException;
}
