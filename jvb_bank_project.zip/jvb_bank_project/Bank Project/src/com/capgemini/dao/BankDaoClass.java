package com.capgemini.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.capgemini.bean.Account;
import com.capgemini.bean.Transaction;
import com.capgemini.util.DBUtil;

public class BankDaoClass implements BankDaoInterface {
	 
	Connection con;

	public BankDaoClass() {
		con = DBUtil.getConnect();

	}

	@Override
	public String addAccount(Account a) throws SQLException, ClassNotFoundException {
		// TODO Auto-generated method stub
		PreparedStatement preparedStatement = con.prepareStatement("INSERT INTO customers VALUES(?,?,?,?,?,?,?,?)");
		preparedStatement.setString(1, a.getFirstName());
		preparedStatement.setString(2, a.getLastName());
		preparedStatement.setString(3, a.getFathersName());
		preparedStatement.setString(4, a.getMothersName());
		preparedStatement.setLong(5, a.getAccountId());
		preparedStatement.setString(6, a.getAddress());
		preparedStatement.setString(7, a.getPassword());
		preparedStatement.setDouble(8, 100.0);
		preparedStatement.executeUpdate();

		return "Created";
	}

	@Override
	public String deposit(Long accountId, Double amount) throws SQLException, ClassNotFoundException {
		Double updateAmount = 0.0;
		PreparedStatement preparedStatement = con.prepareStatement("SELECT * FROM customers WHERE accountId = ?");
		preparedStatement.setLong(1, accountId);
		ResultSet rs = preparedStatement.executeQuery();
		if (rs.next()) {
			double currentbalance = rs.getDouble("balance");
			long id = rs.getLong("accountId");

			if (id == accountId && amount > 0) {				 
				updateAmount = currentbalance + amount;

				PreparedStatement preparedStatement2 = con
						.prepareStatement("update customers SET balance = ? WHERE accountId = ?");
				preparedStatement2.setDouble(1, updateAmount);
				preparedStatement2.setLong(2, accountId);
				preparedStatement2.execute();

				PreparedStatement preparedStatement1 = con
						.prepareStatement("INSERT INTO transaction VALUES(?,?,?,?,?)");
				preparedStatement1.setInt(1, 1);
				preparedStatement1.setLong(2, accountId);
				preparedStatement1.setDate(4, null);
				preparedStatement1.setString(3, "Deposit");
				preparedStatement1.setDouble(5, amount);
				preparedStatement1.execute();

				return "success";
			}

		}
		return "invalid amount";

	}

	@Override
	public String withDraw(Long accountId, Double amount) throws SQLException, ClassNotFoundException {

		Double updateAmount = 0.0;

		PreparedStatement preparedStatement = con.prepareStatement("SELECT * FROM customers WHERE accountId = ?");
		preparedStatement.setLong(1, accountId);
		ResultSet rs = preparedStatement.executeQuery();
		if (rs.next()) {
			double currentbalance = rs.getDouble("balance");
			long id = rs.getLong("accountId");

			if (id == accountId && amount <= currentbalance) {
				PreparedStatement preparedStatement1 = con.prepareStatement("INSERT INTO transaction VALUES(?,?,?,?,?)");
				preparedStatement1.setInt(1, 1);
				preparedStatement1.setLong(2, accountId);
				preparedStatement1.setDate(4, null);
				preparedStatement1.setString(3, "withdraw");
				preparedStatement1.setDouble(5, amount);
				preparedStatement1.execute();
				updateAmount = currentbalance - amount;
				PreparedStatement preparedStatement2 = con.prepareStatement("update customers SET balance = ? WHERE accountId = ?");
				preparedStatement2.setDouble(1, updateAmount);
				preparedStatement2.setLong(2, accountId);
				preparedStatement2.execute();
				return "success";
			}

		}
		return "invalid amount";

	}

	@Override
	public String fundTransfer(Long accountId1, Long accountId2, Double amount)
			throws ClassNotFoundException, SQLException {
		synchronized (this) {

			String status = withDraw(accountId1, amount);

			if (status.equals("success")) {
				deposit(accountId2, amount);
				return "success";
			} else {
				return "Invalid Amount";
			}
		}
	}

	@Override
	public void printTransaction(Long accountId) throws SQLException {

		PreparedStatement preparedStatement = con.prepareStatement("SELECT * FROM transaction WHERE accountId = ?");
		preparedStatement.setLong(1, accountId);
		ResultSet rs = preparedStatement.executeQuery();
		if (rs.next()) {
			while (rs.next()) {
				Long accountId1 = rs.getLong("accountId");
				String type = rs.getString("type");
				 
				Double amount = rs.getDouble("amount");
				Integer transactionId = rs.getInt("transactionId");
				Transaction account = new Transaction(accountId1, type, null, amount, transactionId);
				System.out.println(account);
			}
		} else
			System.out.println("account not found");

	}

	public Boolean uniqueIds(Long id) throws SQLException, ClassNotFoundException {

		PreparedStatement preparedStatement = con.prepareStatement("SELECT * FROM customers WHERE accountId = ?");
		preparedStatement.setLong(1, id);
		ResultSet rs = preparedStatement.executeQuery();
		if (rs.next()) {
			long id1 = rs.getLong("accountId");
			if (id1 == id)
				return true;
		}
		return false;
	}

	public Account listing(Long id) throws SQLException {
		PreparedStatement preparedStatement = con.prepareStatement("SELECT * FROM customers WHERE accountId = ?");
		preparedStatement.setLong(1, id);
		ResultSet rs = preparedStatement.executeQuery();
		if (rs.next()) {
			long id1 = rs.getLong("accountId");
			if (id1 == id)
			{
				String firstName = rs.getString("firstName");
				String lastName = rs.getString("lastName");
				String fathersName = rs.getString("fathersName");
				String mothersName = rs.getString("mothersName");
				Long accountId = id1;
				String password = rs.getString("password");
				String address = rs.getString("address");
				Double balance = rs.getDouble("balance");
				Account account = new Account(firstName, lastName, fathersName, mothersName, accountId, password,address, balance);
				return account;
			}
		}
		return null;
	}

	public boolean checkAccount(Long id, String password) throws SQLException, ClassNotFoundException {
		// for (Account a : account) {

		PreparedStatement preparedStatement = con.prepareStatement("SELECT * FROM customers WHERE accountId = ?");
		preparedStatement.setLong(1, id);
		ResultSet rs = preparedStatement.executeQuery();
		if (rs.next()) {
			long id1 = rs.getLong("accountId");
			String pass = rs.getString("password");
			if (id1 == id && pass.equals(password)) {
				return true;
			}
		}

		return false;
	}

	@Override
	public Double showBalance(Long accountId) throws SQLException, ClassNotFoundException {

		PreparedStatement preparedStatement = con.prepareStatement("SELECT * FROM customers WHERE accountId = ?");
		preparedStatement.setLong(1, accountId);
		ResultSet rs = preparedStatement.executeQuery();
		if (rs.next()) {
			double currentbalance = rs.getDouble("balance");
			return currentbalance;
		}

		return null;
	}

}
