package com.capgemini.dao;

import java.sql.SQLException;
import java.util.List;

import com.capgemini.bean.Account;

public interface BankDaoInterface {

	public String addAccount(Account a) throws SQLException, ClassNotFoundException;

	public String withDraw(Long accountId, Double amount) throws SQLException, ClassNotFoundException;

	public String fundTransfer(Long accountId1, Long accountId2, Double amount)
			throws ClassNotFoundException, SQLException;

	public void printTransaction(Long accountId) throws SQLException;

	public Double showBalance(Long accountId) throws SQLException, ClassNotFoundException;

	public String deposit(Long accountId, Double amount) throws SQLException, ClassNotFoundException;
}
